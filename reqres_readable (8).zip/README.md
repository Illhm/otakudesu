# Export Req/Res (Readable)
Organized by Domain > Request.
- 00_summary.txt : Metadata
- 01_req_headers.txt
- 02_req_body.(json/txt)
- 03_res_headers.txt
- 04_res_body.(json/html/txt/bin)
