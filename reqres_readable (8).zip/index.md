| seq | method | status | domain | path | mime | size |
|---:|:--|:--:|:--|:--|:--|--:|
| 1 | GET | 200 | otakudesu.best | /anime-list/ | text/html | 53791 |
| 28 | GET | 200 | otakudesu.best | /ongoing-anime/ | text/html | 9166 |
| 79 | GET | 200 | web.facebook.com | /v3.2/plugins/page.php | text/html | 0 |
| 85 | GET | 200 | otakudesu.best | /jadwal-rilis/ | text/html | 9010 |
| 112 | GET | 200 | otakudesu.best | /genre-list/ | text/html | 7647 |
| 143 | GET | 200 | web.facebook.com | /v3.2/plugins/page.php | text/html | 0 |
| 144 | GET | 200 | otakudesu.best | / | text/html | 0 |
| 177 | GET | 200 | web.facebook.com | /v3.2/plugins/page.php | text/html | 0 |
| 197 | GET | 200 | otakudesu.best | /anime/shibou-yuugi-meshi-kuu-sub-indo/ | text/html | 9805 |
| 230 | GET | 200 | otakudesu.best | / | text/html | 0 |
| 283 | GET | 200 | web.facebook.com | /v3.2/plugins/page.php | text/html | 0 |
| 284 | GET | 200 | otakudesu.best | /anime/oshi-ko-s3-sub-indo/ | text/html | 9202 |
| 321 |  | 200 | otakudesu.best | /episode/onk-s3-episode-1-sub-indo/ | text/html | 12813 |
| 353 | GET | pending | str.desustream.com | /dstream/ondesu3/v5/index.php |  | 0 |
| 360 |  | 200 | otakudesu.best | /episode/onk-s3-episode-2-sub-indo/ | text/html | 12970 |
| 392 | GET | pending | str.desustream.com | /dstream/ondesu/v5/index.php |  | 0 |
| 395 | GET | 200 | otakudesu.best | /genre-list/ | text/html | 0 |
| 428 | GET | pending | www.facebook.com | /v3.2/plugins/page.php |  | 0 |
| 429 |  | 200 | otakudesu.best | /genres/romance/ | text/html | 8965 |
| 469 | GET | 200 | otakudesu.best | /genres/romance/page/2/ | text/html | 9686 |
| 507 | GET | 200 | otakudesu.best | /genres/romance/page/3/ | text/html | 9987 |
| 545 | GET | 200 | otakudesu.best | / | text/html | 0 |
| 598 | GET | 200 | web.facebook.com | /v3.2/plugins/page.php | text/html | 0 |
| 599 | GET | 200 | otakudesu.best | /anime-list/ | text/html | 0 |
| 630 | GET | 200 | otakudesu.best | / | text/html | 0 |
| 683 | GET | 200 | web.facebook.com | /v3.2/plugins/page.php | text/html | 0 |
| 684 | GET | 200 | otakudesu.best | /anime/oshi-ko-s3-sub-indo/ | text/html | 0 |
| 717 |  | 200 | otakudesu.best | /episode/onk-s3-episode-1-sub-indo/ | text/html | 0 |
| 753 | GET | 200 | str.desustream.com | /dstream/ondesu3/v5/index.php | text/html | 2363 |
| 758 | GET | 200 | www.blogger.com | /video.g | text/html | 1305 |
| 765 | GET | 200 | youtube.googleapis.com | /embed/ | text/html | 46470 |
| 779 | OPTIONS | 200 | jnn-pa.googleapis.com | /$rpc/google.internal.waa.v1.Waa/GenerateIT | text/html | 0 |
| 799 | GET | 200 | filedon.co | /embed/QvvubTKG5k | text/html | 14950 |
| 824 | GET | 200 | odvidhide.com | /embed/yblec6u1eavr | text/html | 32147 |
| 846 | GET | 200 | odvidhide.com | /embed/7vh4zo2k5378 | text/html | 32014 |
| 872 | GET | 200 | mega.nz | /embed/sixEgCCa | text/html | 1653 |
| 883 | GET | 200 | mega.nz | /embed/sixEgCCa | text/html | 1653 |
| 894 | GET | 200 | mega.nz | /embed/piZjzKTR | text/html | 1653 |
